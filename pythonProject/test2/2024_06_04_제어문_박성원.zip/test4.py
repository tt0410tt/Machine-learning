class a:
    b=1
    def c(self):
        i=0
        for i in range(1,101):
            print(i)
a.c(a)
