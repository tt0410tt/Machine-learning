class a:
    b=1
    def c(self,number):
        if number%2==1:
            return print("True")
        else:
            return print("False")
a.c(a,1)
