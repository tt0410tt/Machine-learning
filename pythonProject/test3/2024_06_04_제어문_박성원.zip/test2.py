class a:
    b=1
    def c(self,numbers):
        result=0
        for i in numbers:
            result+=i
        return print(result)
a.c(a,[1,3,5,6,7,8,9])
