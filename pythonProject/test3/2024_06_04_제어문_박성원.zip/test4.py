class a:
    b=1
    def c(self,numbers):
        print("you" "need" "python")
        print("you" + "need" + "python")
        print("you", "need", "python")
        print("".join(["you", "need", "python"]))
        
        return print("")
a.c(a,[1,3,5,6,7,8,9])

print("1,2,4 번은 그냥 문자열을 넣어줌으로 써 한 매개변수에 다 연결한것이고 3번은 매개변수를 여러개 줌으로 써 다른인자를 보낸것이기 때문이다")