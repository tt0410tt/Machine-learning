class a:
    c=[1,3,5,4,2]
    def b(self):
        d=self.c.sort()
        print(self.c)
        e=self.c.reverse()
        print(self.c)
a.b(a)
