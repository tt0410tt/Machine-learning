class a:
    c=dict()
    def b(self):
        self.c['name']='python'
        self.c[('a',)]='python'
        self.c[[1]]='python'
        self.c[250]='python'
        
a.b(a)
