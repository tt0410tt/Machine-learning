class a:
    c="881120-1068234"
    def b(self):
        d=self.c.split("-")
        yyyymmdd=d[0]
        number=d[1]
        print(yyyymmdd)
        print(number)

a.b(a)
