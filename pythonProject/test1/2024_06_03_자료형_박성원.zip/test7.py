class a:
    c=["life","is","too","short"]
    def b(self):
        d=""
        for i in self.c:
            d=d+i
            d=d+" "
        print(d)
a.b(a)
