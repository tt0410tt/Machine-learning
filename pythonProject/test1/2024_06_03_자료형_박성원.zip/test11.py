class a:
    a = [1,1,1,2,2,2,3,3,3,4,4,5]
    def b(self):
        aset=set(self.a)
        b=list(aset)
        print(b)
        
a.b(a)
