class a:
    c="881120-1068234"
    def b(self):
        d=self.c.split("-")
        print(d[1][0])

a.b(a)
