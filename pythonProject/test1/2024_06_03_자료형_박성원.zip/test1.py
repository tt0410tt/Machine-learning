class a:
    c={"국어" : 80,"영어": 75, "수학":55}
    def b(self):
        print((a.c["국어"]+a.c["영어"]+a.c["수학"])/3)

a.b(a)
